# ProxyManager Local Setup Script
# Run this script as Administrator from the extracted folder.

$InstallDir = "C:\ProxyManager"
$ServiceName = "ProxyManagerAgent"
# We'll use the domain name for the server address
$ServerAddr = "proxy.ovncr.vn:50051"

# 1. Check for Admin rights
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Please run this script as Administrator!"
    exit
}

# 2. Create directory and copy files
if (!(Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir
}

Write-Host "Copying files to $InstallDir..."
Copy-Item -Path "agent.exe", "frpc.exe" -Destination $InstallDir -Force

# 3. Setup Service
if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    Write-Host "Stopping and removing existing service..."
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName
    Start-Sleep -s 2
}

Write-Host "Creating Windows Service..."
New-Service -Name $ServiceName `
            -BinaryPathName "`"$InstallDir\agent.exe`" -server $ServerAddr" `
            -DisplayName "ProxyManager Client Agent" `
            -StartupType Automatic `
            -Description "Monitors host and manages FRP tunnels"

Write-Host "Starting service..."
Start-Service -Name $ServiceName

Write-Host "-------------------------------------------"
Write-Host "Setup Completed Successfully!"
Write-Host "The agent is now running from $InstallDir"
Write-Host "-------------------------------------------"
pause
